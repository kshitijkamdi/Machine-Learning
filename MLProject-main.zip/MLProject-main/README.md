This Project Explains Medical Abreviation in Simple terms, We have used the MeDal Dataset for this project. At first we tried making it using a LLM, 
But due to the quality of the embeddings and other issues, there were many hallucinations. So we switched to a KNN. We have made the front end using anvil its link is
https://those-sad-sort.anvil.app
